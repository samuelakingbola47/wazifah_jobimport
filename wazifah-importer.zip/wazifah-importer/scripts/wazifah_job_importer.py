#!/usr/bin/env python3
"""
Wazifah Job Importer
=====================
Python re-implementation of the "a new wazifah" Make.com scenario.

Pipeline:
  1. Run an Apify actor (LinkedIn Jobs Scraper) synchronously and pull the
     resulting dataset.
  2. For every scraped job:
       - classify it into a sub-category and main-category based on title
         keywords (same rules as the original Make.com scenario)
       - map the main-category to the matching job_field taxonomy term ID
       - download the company logo (if the scraper found one)
       - upload the logo to the WordPress media library
       - create a `job_listing` post with the correct meta fields, taxonomy
         terms, and featured image

Environment variables required (see README.md / GitHub Actions secrets):
  APIFY_TOKEN        Apify API token
  WP_BASE_URL        e.g. https://my-wazifah.com
  WP_USERNAME        WordPress username
  WP_APP_PASSWORD    WordPress Application Password (Users > Profile)

Optional:
  LINKEDIN_SEARCH_URLS   JSON array of LinkedIn job-search URLs to scrape.
                          Defaults to the two URLs used in the original scenario.
  APIFY_ACTOR_ID          Defaults to the actor used in the original scenario
                          (curious_coder/linkedin-jobs-scraper -> hKByXkMQaC5Qt9UMN)
  APIFY_MAX_RESULTS       Defaults to 3 (per search URL)
  DEFAULT_JOB_COUNTRY_ID  Term ID for job_country. Defaults to 153 (Saudi Arabia)
  DEFAULT_JOB_SECTOR_ID   Term ID for job_sector. Defaults to 167 (Private)
  DRY_RUN                 If set to "1", jobs are scraped/classified/logged but
                          NOT written to WordPress. Useful for testing.
"""

import os
import sys
import json
import time
import logging
from typing import Optional

import requests

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("wazifah-importer")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

APIFY_TOKEN = os.environ.get("APIFY_TOKEN")
WP_BASE_URL = os.environ.get("WP_BASE_URL", "").rstrip("/")
WP_USERNAME = os.environ.get("WP_USERNAME")
WP_APP_PASSWORD = os.environ.get("WP_APP_PASSWORD")

APIFY_ACTOR_ID = os.environ.get("APIFY_ACTOR_ID", "hKByXkMQaC5Qt9UMN")
APIFY_MAX_RESULTS = int(os.environ.get("APIFY_MAX_RESULTS", "3"))

DEFAULT_SEARCH_URLS = [
    "https://www.linkedin.com/jobs/search/?keywords=Civil+Engineer&geoId=100459316&f_TPR=r604800",
    "https://www.linkedin.com/jobs/search/?keywords=Software+Developer&geoId=100459316&f_TPR=r604800",
]
LINKEDIN_SEARCH_URLS = json.loads(
    os.environ.get("LINKEDIN_SEARCH_URLS", json.dumps(DEFAULT_SEARCH_URLS))
)

DEFAULT_JOB_COUNTRY_ID = int(os.environ.get("DEFAULT_JOB_COUNTRY_ID", "153"))  # Saudi Arabia
DEFAULT_JOB_SECTOR_ID = int(os.environ.get("DEFAULT_JOB_SECTOR_ID", "167"))    # Private

DRY_RUN = os.environ.get("DRY_RUN", "0") == "1"

# job_field taxonomy term IDs (confirmed real IDs from the site)
JOB_FIELD_IDS = {
    "Administration & Management": 162,
    "Construction & Infrastructure": 175,
    "Customer Service": 165,
    "Education": 163,
    "Engineering": 159,
    "Finance & Accounting": 164,
    "Healthcare": 160,
    "Human Resources": 174,
    "Information Technology": 161,
    "Sales & Marketing": 172,
    # Fallback bucket. NOTE: the original Make.com scenario fell back to the
    # numeric ID 163 ("Education") for anything that didn't match a rule,
    # even though the fallback category name was "General". That looks like
    # a bug in the original scenario. We keep the same *behaviour* here for
    # parity, but log a warning so it's easy to spot/fix.
    "General": 163,
}

# ---------------------------------------------------------------------------
# Category classification (ported 1:1 from the Make.com SetVariable formulas)
# ---------------------------------------------------------------------------

SUB_CATEGORY_RULES = [
    (["electrical engineer"], "Electrical Engineering"),
    (["mechanical engineer"], "Mechanical Engineering"),
    (["civil engineer"], "Civil Engineering"),
    (["chemical engineer"], "Chemical Engineering"),
    (["industrial engineer"], "Industrial Engineering"),
    (["software engineer", "software developer", "frontend", "backend", "full stack"], "Software Development"),
    (["network engineer"], "Network Engineering"),
    (["cybersecurity", "cyber security", "information security"], "Cybersecurity"),
    (["cloud engineer", "cloud architect"], "Cloud Computing"),
    (["data scientist", "data analyst", "data engineer"], "Data Science"),
    (["machine learning", "artificial intelligence"], "AI & Machine Learning"),
    (["chief accountant", "senior accountant", "accountant"], "Accounting"),
    (["financial analyst", "finance manager", "cfo"], "Finance"),
    (["banking", "bank manager"], "Banking"),
    (["investment analyst", "portfolio manager"], "Investment"),
    (["project manager", "program manager"], "Project Management"),
    (["operations manager", "operations director"], "Operations Management"),
    (["office manager", "administrative assistant", "office administrator"], "Office Administration"),
    (["hr manager", "human resources manager", "hr director"], "HR Management"),
    (["recruiter", "recruitment manager"], "Recruitment"),
    (["talent acquisition"], "Talent Acquisition"),
    (["sales manager", "sales executive", "sales representative"], "Sales"),
    (["digital marketing", "seo specialist", "social media manager"], "Digital Marketing"),
    (["business development manager", "business development executive"], "Business Development"),
    (["brand manager", "marketing manager"], "Brand Marketing"),
    (["doctor", "physician", "medical officer"], "Medical"),
    (["nurse", "nursing"], "Nursing"),
    (["pharmacist", "pharmaceutical"], "Pharmaceutical"),
    (["healthcare manager", "health manager"], "Healthcare Management"),
    (["construction manager", "site manager"], "Construction Management"),
    (["architect"], "Architecture"),
    (["quantity surveyor"], "Quantity Surveying"),
    (["customer service", "customer support", "call center"], "Customer Service"),
    (["logistics", "supply chain", "procurement"], "Logistics & Supply Chain"),
    (["intern", "graduate trainee", "entry level"], "Internships & Student Programs"),
]

MAIN_CATEGORY_RULES = [
    (["Engineering", "Electrical", "Mechanical", "Civil", "Chemical", "Industrial"], "Engineering"),
    (["Software", "Cyber", "Cloud", "Data", "AI", "Network"], "Information Technology"),
    (["Sales", "Marketing", "Business Development", "Brand"], "Sales & Marketing"),
    (["Accounting", "Finance", "Banking", "Investment"], "Finance & Accounting"),
    (["HR", "Recruitment", "Talent"], "Human Resources"),
    (["Office", "Operations", "Project"], "Administration & Management"),
    (["Medical", "Nursing", "Pharmaceutical", "Healthcare"], "Healthcare"),
    (["Construction", "Architecture", "Quantity"], "Construction & Infrastructure"),
    (["Internships"], "Internships & Student Programs"),
]


def classify_sub_category(title: str) -> str:
    title_l = (title or "").lower()
    for keywords, label in SUB_CATEGORY_RULES:
        if any(kw in title_l for kw in keywords):
            return label
    return "General"


def classify_main_category(sub_category: str) -> str:
    for keywords, label in MAIN_CATEGORY_RULES:
        if any(kw in sub_category for kw in keywords):
            return label
    return "General"


def main_category_to_field_id(main_category: str) -> int:
    field_id = JOB_FIELD_IDS.get(main_category)
    if field_id is None:
        log.warning("Unmapped main_category '%s' -> falling back to General (163)", main_category)
        field_id = JOB_FIELD_IDS["General"]
    return field_id


# ---------------------------------------------------------------------------
# Apify
# ---------------------------------------------------------------------------

def run_apify_actor_and_get_items() -> list:
    """Runs the actor synchronously and returns the dataset items."""
    if not APIFY_TOKEN:
        log.error("APIFY_TOKEN is not set.")
        sys.exit(1)

    url = f"https://api.apify.com/v2/acts/{APIFY_ACTOR_ID}/run-sync-get-dataset-items"
    params = {"token": APIFY_TOKEN}
    payload = {
        "urls": LINKEDIN_SEARCH_URLS,
        "maxResults": APIFY_MAX_RESULTS,
        "scrapeCompanyDetails": True,
    }

    log.info("Running Apify actor %s for %d search URL(s)...", APIFY_ACTOR_ID, len(LINKEDIN_SEARCH_URLS))
    resp = requests.post(url, params=params, json=payload, timeout=600)
    resp.raise_for_status()
    items = resp.json()
    log.info("Apify returned %d job item(s).", len(items))
    return items


# ---------------------------------------------------------------------------
# WordPress helpers
# ---------------------------------------------------------------------------

def wp_auth():
    if not (WP_BASE_URL and WP_USERNAME and WP_APP_PASSWORD):
        log.error("WP_BASE_URL, WP_USERNAME and WP_APP_PASSWORD must all be set.")
        sys.exit(1)
    return (WP_USERNAME, WP_APP_PASSWORD)


def download_logo(logo_url: Optional[str]) -> Optional[bytes]:
    if not logo_url:
        return None
    try:
        resp = requests.get(logo_url, timeout=30)
        resp.raise_for_status()
        return resp.content
    except requests.RequestException as e:
        log.warning("Failed to download company logo (%s): %s", logo_url, e)
        return None


def upload_media(company_name: str, logo_bytes: bytes, filename: str) -> Optional[dict]:
    """Uploads an image to the WP media library. Returns the media JSON (with id + source_url)."""
    endpoint = f"{WP_BASE_URL}/wp-json/wp/v2/media"
    safe_filename = filename or f"{company_name or 'company'}-logo.jpg"
    headers = {
        "Content-Disposition": f'attachment; filename="{safe_filename}"',
        "Content-Type": "image/jpeg",
    }
    try:
        resp = requests.post(endpoint, headers=headers, data=logo_bytes, auth=wp_auth(), timeout=60)
        resp.raise_for_status()
        media = resp.json()
        media_id = media.get("id")

        # Set title / alt text in a follow-up PATCH (multipart upload above
        # only reliably sets the file itself on most WP REST setups).
        if media_id:
            requests.post(
                f"{endpoint}/{media_id}",
                json={
                    "title": f"{company_name}-logo",
                    "alt_text": f"{company_name} company logo",
                },
                auth=wp_auth(),
                timeout=30,
            )
        return media
    except requests.RequestException as e:
        log.warning("Failed to upload media for %s: %s", company_name, e)
        return None


def create_job_post(job: dict, main_field_id: int, media: Optional[dict]) -> Optional[dict]:
    endpoint = f"{WP_BASE_URL}/wp-json/wp/v2/job_listing"

    apply_url = job.get("applyUrl") or job.get("link")

    meta = {
        "company_name": job.get("companyName", ""),
        "job_location": job.get("location", ""),
        "application_link": apply_url or "",
        "job_employment_type": job.get("employmentType", ""),
        "source_url": job.get("link", ""),
    }
    if media and media.get("source_url"):
        # Store the actual image URL here (the original scenario mistakenly
        # stored the numeric media ID in this field, which is one likely
        # reason logos weren't rendering everywhere they were expected).
        meta["company_logo_url"] = media["source_url"]

    payload = {
        "title": job.get("title", ""),
        "status": "publish",
        "content": job.get("descriptionText", ""),
        "date": job.get("postedAt") or None,
        "meta": meta,
        "job_field": [main_field_id],
        "job_country": [DEFAULT_JOB_COUNTRY_ID],
        "job_sector": [DEFAULT_JOB_SECTOR_ID],
    }
    if media and media.get("id"):
        payload["featured_media"] = media["id"]

    # Drop empty date so WP just uses "now"
    if not payload["date"]:
        payload.pop("date")

    try:
        resp = requests.post(endpoint, json=payload, auth=wp_auth(), timeout=60)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        body = getattr(e.response, "text", "")
        log.error("Failed to create job_listing post for '%s': %s | %s", job.get("title"), e, body)
        return None


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def process_job(job: dict):
    title = job.get("title", "(no title)")
    company = job.get("companyName", "(unknown company)")

    sub_cat = classify_sub_category(title)
    main_cat = classify_main_category(sub_cat)
    field_id = main_category_to_field_id(main_cat)

    log.info("Job: '%s' @ %s -> sub='%s' main='%s' job_field_id=%s", title, company, sub_cat, main_cat, field_id)

    if DRY_RUN:
        log.info("[DRY_RUN] Skipping WordPress write for '%s'.", title)
        return

    media = None
    logo_url = job.get("companyLogo")
    logo_bytes = download_logo(logo_url)
    if logo_bytes:
        media = upload_media(company, logo_bytes, f"{company}-logo.jpg")
        if media:
            log.info("Uploaded logo for '%s' -> media ID %s", company, media.get("id"))
    else:
        log.info("No usable company logo for '%s' (source: %r); post will use theme fallback bubble.", company, logo_url)

    post = create_job_post(job, field_id, media)
    if post:
        log.info("Created post ID %s for '%s'.", post.get("id"), title)


def main():
    items = run_apify_actor_and_get_items()
    if not items:
        log.info("No jobs returned from Apify. Nothing to do.")
        return

    for job in items:
        try:
            process_job(job)
        except Exception as e:  # keep going even if one job fails
            log.exception("Unhandled error processing job '%s': %s", job.get("title"), e)
        time.sleep(1)  # be gentle with the WP REST API


if __name__ == "__main__":
    main()
