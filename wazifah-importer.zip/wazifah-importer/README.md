# Wazifah Job Importer

Python re-implementation of the "a new wazifah" Make.com scenario. Scrapes
LinkedIn jobs via Apify and posts them to the `job_listing` custom post type
on my-wazifah.com through the WordPress REST API — no Make.com needed.

## What it does (same pipeline as the Make blueprint)

1. Calls the Apify actor `curious_coder/linkedin-jobs-scraper` synchronously
   for each configured LinkedIn search URL.
2. For every job returned:
   - Classifies the job title into a sub-category, then a main-category
     (identical keyword rules to the original scenario).
   - Maps the main-category to the correct `job_field` taxonomy term ID.
   - Downloads the company logo (if the scraper found one) and uploads it
     to the WP media library.
   - Creates a `job_listing` post with:
     - `company_name`, `job_location`, `application_link`,
       `job_employment_type`, `source_url`, `company_logo_url` meta fields
     - `job_field` term (auto-classified), `job_country` (default: Saudi
       Arabia, 153), `job_sector` (default: Private, 167)
     - Featured image set to the uploaded logo, so job cards and the single
       job page pick it up automatically via `get_the_post_thumbnail()`.

### One fix vs. the original Make scenario
The original blueprint stored the numeric media ID in the `company_logo_url`
meta field instead of the actual image URL, and would silently produce a
post with **no** featured image if the logo download failed (e.g. Apify
didn't find a `companyLogo` for that listing). This script:
- Stores the real image URL in `company_logo_url`.
- Still creates the job post even if there is no logo — the post just has no
  featured image, so your theme's letter-bubble fallback kicks in instead of
  the whole job failing to import.

## Setup

### 1. Create a WordPress Application Password
WordPress admin → Users → your profile → **Application Passwords** → create
one named e.g. `github-importer`. Copy the generated password (spaces and
all) — you won't see it again.

### 2. Add GitHub repo secrets
In your GitHub repo: **Settings → Secrets and variables → Actions → New
repository secret**, add:

| Secret name        | Value                                      |
|---------------------|---------------------------------------------|
| `APIFY_TOKEN`       | Your Apify API token                       |
| `WP_BASE_URL`       | `https://my-wazifah.com`                   |
| `WP_USERNAME`       | Your WP username                           |
| `WP_APP_PASSWORD`   | The Application Password from step 1       |

### 3. Push this repo to GitHub
```bash
git init
git add .
git commit -m "Wazifah job importer"
git branch -M main
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```

### 4. Run it
- It runs automatically every 6 hours (edit the cron line in
  `.github/workflows/import-jobs.yml` to change the schedule).
- Or trigger it manually: repo → **Actions** → "Import Wazifah Jobs" →
  **Run workflow**.

## Local testing
```bash
pip install -r requirements.txt

export APIFY_TOKEN=xxx
export WP_BASE_URL=https://my-wazifah.com
export WP_USERNAME=youruser
export WP_APP_PASSWORD="xxxx xxxx xxxx xxxx"
export DRY_RUN=1   # scrapes + classifies but does NOT write to WordPress

python scripts/wazifah_job_importer.py
```
Set `DRY_RUN=0` (or unset it) once you're happy with the console output to
actually create posts.

## Configuration (optional environment variables)
- `LINKEDIN_SEARCH_URLS` — JSON array of LinkedIn job-search URLs to scrape.
  Defaults to the two searches from the original scenario (Civil Engineer,
  Software Developer, both Gulf-region).
- `APIFY_ACTOR_ID` — defaults to the actor used originally
  (`hKByXkMQaC5Qt9UMN`).
- `APIFY_MAX_RESULTS` — results per search URL (default `3`).
- `DEFAULT_JOB_COUNTRY_ID` / `DEFAULT_JOB_SECTOR_ID` — the original scenario
  hardcoded every job to Saudi Arabia / Private sector. Change these term
  IDs if you want a different default, or extend the script to detect
  country/sector from the scraped data instead.

## Important notes
- **This only replaces the scraping + posting scenario.** Your existing
  `gulf-jobs-core` plugin, taxonomies, and theme are untouched — this script
  just talks to the same REST API your Make.com scenario was using.
- Meta fields and taxonomies must be REST-exposed on the WordPress side for
  this to work (they already are, since Make.com was successfully posting
  through the same REST API).
- Turning off/deleting the old Make.com scenario is up to you — you can run
  both in parallel for a bit to compare results, just watch out for
  duplicate postings if both are scraping the same searches.
